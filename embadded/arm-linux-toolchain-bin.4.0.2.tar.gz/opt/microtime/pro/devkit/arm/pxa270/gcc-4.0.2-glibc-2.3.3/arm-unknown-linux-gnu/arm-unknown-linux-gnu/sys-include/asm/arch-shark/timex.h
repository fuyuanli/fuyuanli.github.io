/*
 * linux/include/asm-arm/arch-shark/timex.h
 *
 * by Alexander Schulz
 */

#define CLOCK_TICK_RATE 1193180
