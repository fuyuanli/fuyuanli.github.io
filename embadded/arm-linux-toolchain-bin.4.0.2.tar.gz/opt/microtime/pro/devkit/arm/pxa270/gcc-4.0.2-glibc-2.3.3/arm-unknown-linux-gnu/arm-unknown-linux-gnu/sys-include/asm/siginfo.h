#ifndef _ASMARM_SIGINFO_H
#define _ASMARM_SIGINFO_H

#include <linux/siginfo.h>

#endif
