/*
 * linux/include/asm-arm/arch-iop3xx/dma.h
 *
 *  Copyright (C) 2004 Intel Corp.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#ifndef _IOP3XX_DMA_H_P
#define _IOP3XX_DMA_H_P

#define MAX_DMA_ADDRESS		0xffffffff

#endif /* _ASM_ARCH_DMA_H_P */
