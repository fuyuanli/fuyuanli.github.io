#warning "You should include <sys/io.h>. This time I will do it for you."
#include <sys/io.h>

