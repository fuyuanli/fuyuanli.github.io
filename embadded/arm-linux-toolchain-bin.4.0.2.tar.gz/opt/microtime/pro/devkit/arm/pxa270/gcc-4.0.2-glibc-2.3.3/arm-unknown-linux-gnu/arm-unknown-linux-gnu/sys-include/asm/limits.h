#ifndef __ASM_PIPE_H
#define __ASM_PIPE_H

#ifndef PAGE_SIZE
#include <asm/page.h>
#endif

#define PIPE_BUF	PAGE_SIZE

#endif

