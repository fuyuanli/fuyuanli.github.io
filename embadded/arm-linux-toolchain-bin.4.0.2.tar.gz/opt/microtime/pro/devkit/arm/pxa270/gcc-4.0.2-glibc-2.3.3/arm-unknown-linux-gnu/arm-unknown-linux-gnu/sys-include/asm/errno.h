#ifndef _ARM_ERRNO_H
#define _ARM_ERRNO_H

#ifndef _LINUX_ERRNO_H
 #include <linux/errno.h>
#endif

#endif
