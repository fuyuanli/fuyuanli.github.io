/* include/asm-arm/arch-lh7a40x/irq.h
 *
 *  Copyright (C) 2004 Logic Product Development
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  version 2 as published by the Free Software Foundation.
 *
 */

void __init lh7a40x_init_board_irq (void);
