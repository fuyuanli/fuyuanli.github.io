/*
 *  linux/include/asm-arm/arch-ixp2000/param.h
 */
