/*
 * Moved to new location
 */
#warning using old SA-1111.h - update to <asm/hardware/sa1111.h>
#include <asm/hardware/sa1111.h>
