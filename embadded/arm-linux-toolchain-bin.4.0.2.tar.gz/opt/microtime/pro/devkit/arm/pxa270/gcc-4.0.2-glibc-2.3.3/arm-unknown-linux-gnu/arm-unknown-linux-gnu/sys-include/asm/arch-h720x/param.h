/*
 * linux/include/asm-arm/arch-h720x/param.h
 *
 * Copyright (C) 2000 Jungjun Kim
 */

#ifndef __ASM_ARCH_PARAM_H
#define __ASM_ARCH_PARAM_H

#endif
