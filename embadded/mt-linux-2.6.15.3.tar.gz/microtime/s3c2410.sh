#!/bin/sh
rm -f linux
ln -s  pro/devkit/lsp/s3c2410/linux-2.4.18  linux
