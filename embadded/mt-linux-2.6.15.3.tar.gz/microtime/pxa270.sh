#!/bin/sh
rm -f linux
ln -s  pro/devkit/lsp/create-pxa270/linux-2.6.15.3   linux
